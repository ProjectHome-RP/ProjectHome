import game from 'natives';

game.setPedDefaultComponentVariation(game.playerPedId());

