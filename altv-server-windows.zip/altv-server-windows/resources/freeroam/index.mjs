import alt from 'alt';

alt.on('playerConnect', (player) => {
  player.spawn(0, 0, 72, 0);
});
