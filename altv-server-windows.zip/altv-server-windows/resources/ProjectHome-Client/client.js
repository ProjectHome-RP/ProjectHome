/// <reference types="@altv/types-client" />
/// <reference types= "@altv/types-natives" />

import * as alt from 'alt-client';
import * as native from 'natives';


alt.onServer('ProjectHome_001:notify', (msg)=> {
    native.beginTextCommandThefeedPost('STRING');
    native.addTextComponentSubstringPlayerName(msg);
    native.endTextCommandThefeedPostTicker(false, true);

   //alt.emitServer('eventname', params);
} );